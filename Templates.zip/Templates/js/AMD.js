(function(root, factory ) {
    if ( typeof define === "function" && define.amd ) {
        define( [ "jquery" ], factory );
    } else if (typeof exports === 'object') {
        module.exports = factory();
    } else {
        root.methods = factory( jQuery );
    }
}(this, function( $ ) {
	
}))