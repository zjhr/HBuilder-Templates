require.config({
    baseUrl: "../js/libs",
    paths: {
		"fastclick":"fastclick.min",
	    "jquery": "jquery.min",
        'oneajax':'oneajax',
	    "weui":"jquery-weui.min",
	    "fun" : "methods",
	    "weixin":"jweixin-1.0.0",
	    'zjhr':'zjhrFun',
	    'init':'zjhrInit'
    },
    shim:{
    	"weui":{
    		deps:['jquery'],
    	},
      "oneajax":{
        deps:['jquery']
      },
    },
    waitSeconds: 0
});
require(['jquery','fastclick','fun','weui','weixin','zjhr','init','oneajax'],function($,fast,fun,weui,wx,zjhr,zjhrinit,oneajax){
	
})
