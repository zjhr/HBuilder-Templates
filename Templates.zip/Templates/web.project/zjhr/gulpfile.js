var gulp = require('gulp');
var browserSync = require('browser-sync').create();
var autoprefixer = require('gulp-autoprefixer');
var gulp = require('gulp');
var concat = require('gulp-concat');                            //- 多个文件合并为一个；
var minifyCss = require('gulp-minify-css');                     //- 压缩CSS为一行；
var rev = require('gulp-rev');                                  //- 对文件名加MD5后缀
var revCollector = require('gulp-rev-collector');               //- 路径替换


gulp.task('css', function () {
    gulp.src(['./portalweb/css/portallayout/iconfont.css',
     './portalweb/css/portallayout/index.css',
     './portalweb/css/portallayout/web.css',
     './portalweb/css/portallayout/style.css'])
        .pipe(autoprefixer({
            browsers: ['last 2 versions', 'Android >= 4.0'],
            cascade: true, //是否美化属性值 默认：true 像这样：
            //-webkit-transform: rotate(45deg);
            //        transform: rotate(45deg);
            remove:true //是否去掉不必要的前缀 默认：true 
        }))
        .pipe(gulp.dest('./portalweb/css/portallayout/dist/css'));
});

gulp.task('concat', function() {                                //- 创建一个名为 concat 的 task
    gulp.src(['./portalweb/css/portallayout/dist/css/iconfont.css',
     './portalweb/css/portallayout/dist/css/index.css',
     './portalweb/css/portallayout/dist/css/web.css',
     './portalweb/css/portallayout/dist/css/style.css'])    							//- 需要处理的css文件，放到一个字符串数组里
        .pipe(concat('wap.min.css'))                            //- 合并后的文件名
        .pipe(minifyCss())                                      //- 压缩处理成一行
        .pipe(rev())                                            //- 文件名加MD5后缀
        .pipe(gulp.dest('./portalweb/css/portallayout'))                               //- 输出文件本地
        .pipe(rev.manifest())                                   //- 生成一个rev-manifest.json
        .pipe(gulp.dest('./portalweb/rev'));                              //- 将 rev-manifest.json 保存到 rev 目录内
});

gulp.task('rev', function() {
    gulp.src(['./portalweb/rev/*.json', './portalweb/jsp/portaldesigner/portalLoyout.jsp'])   //- 读取 rev-manifest.json 文件以及需要进行css名替换的文件
        .pipe(revCollector())                                   //- 执行文件内css名的替换
        .pipe(gulp.dest('./portalweb/jsp/portaldesigner/'));                     //- 替换后的文件输出的目录
});

gulp.task('browser-sync', function() {
	var files = [
		'**/*.html',
		'**/*.css',
		'**/*.js'
	];
	browserSync.init(files, {
		server: {
			baseDir: "./"
		}
	});
});
gulp.task('browser-sync-proxy', function() {
	var files = [
		'./portalweb/**/*.html',
		'./portalweb/**/*.jsp',
		'./portalweb/**/*.css',
		'./portalweb/**/*.js'
	];
	browserSync.init(files, {
		proxy: "localhost:8080/pdweb/portalweb/jsp/portaldesigner/portalLoyout.jsp"
	});
});
gulp.task('default', ['browser-sync']);
gulp.task('proxy', ['browser-sync-proxy']);
gulp.task('cssgo', ['css','concat', 'rev']);