var gulp = require('gulp');
var browserSync = require('browser-sync').create();

gulp.task('browser-sync', function() {
	var files = [
		'**/*.html',
		'**/*.css',
		'**/*.js'
	];
	browserSync.init(files, {
		server: {
			baseDir: "./"
		}
	});
});
gulp.task('browser-sync-proxy', function() {
	var files = [
		'**/*.html',
		'**/*.jsp',
		'**/*.css',
		'**/*.js'
	];
	browserSync.init(files, {
		proxy: "localhost:8080"
	});
});
gulp.task('default', ['browser-sync']);
gulp.task('proxy', ['browser-sync-proxy']);