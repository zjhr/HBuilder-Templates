require.config({
    baseUrl: "js/libs",
    paths: {
      "jquery": "jquery.min",
      "weui":"jquery-weui.min",
      "fun" : "methods",
      "weixin":"jweixin-1.0.0",
      'swiper':'swiper.min',
      'init':'zjhrInit'
    },
    shim:{
    	"weui":{
    		deps:['jquery']
    	},
    },
    urlArgs: "bust=1.0",
    waitSeconds: 0
});
require(['jquery','fun','weui','weixin','init'],function($,fun,weui,wx,zjhrinit){
	var index={
		elem:function(){
			var _$={
				
			}
			$.extend(_$,zjhrinit.zjhrinit)
			return _$;
		},
		init:function(){
			var _self = this;
			$.extend(_self,_self.elem());
			_self.elem=null;
//			_self;
			_self.funevent(_self);
		}
	}
	index.init();
})
