require.config({
    baseUrl: "js/libs",
    paths: {
      "jquery": "jquery.min",
      "weui":"jquery-weui.min",
      "zjhr":"zjhrFun",
      "text":"text"
    },
    shim:{
    	"weui":{
    		deps:['jquery']
    	},
    },
    urlArgs: "bust=1.0",
    waitSeconds: 0
});
require(['jquery','weui',"zjhr","text"],function($,weui,zjhr,text){
	
})
